package com.example.nasaphotoapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    // Klucz API
    private static final String API_KEY = "aQpp4FUrEwUWm3X7ZqLVneBOWmfZxDS1LO1Bb4bW";


    private ImageView photoImageView; // Wyświetlanie zdjęcie dnia
    private TextView titleTextView; // Wyświetlanie tytułu zdjęcia
    private TextView descriptionTextView; // Wyświetlanie opisu zdjęcia
    private TextView daysSinceTextView; // Wyświetlanie liczby dni od publikacji
    private EditText dateEditText; // Pole do wpisania daty w formacie YYYY-MM-DD

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicjalizacja widoków
        photoImageView = findViewById(R.id.photoImageView);
        titleTextView = findViewById(R.id.titleTextView);
        descriptionTextView = findViewById(R.id.descriptionTextView);
        daysSinceTextView = findViewById(R.id.daysSinceTextView);
        dateEditText = findViewById(R.id.dateEditText);

        // Przyciski do obsługi zdarzeń
        Button loadPhotoButton = findViewById(R.id.loadPhotoButton);
        loadPhotoButton.setOnClickListener(v -> loadPhotoOfTheDay()); // Ładowanie zdjęcia dnia

        Button loadPhotoByDateButton = findViewById(R.id.loadPhotoByDateButton);
        loadPhotoByDateButton.setOnClickListener(v -> {
            String date = dateEditText.getText().toString();
            if (!date.isEmpty()) {
                loadPhotoByDate(date); // Ładowanie zdjęcia z wybranej daty
            } else {
                Toast.makeText(this, "Please enter a date", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Pobiera zdjęcie dnia z API
    private void loadPhotoOfTheDay() {
        NasaApiService apiService = RetrofitClient.getInstance(); // Pobranie instancji Retrofit
        Call<NasaPhoto> call = apiService.getPhotoOfTheDay(API_KEY);

        call.enqueue(new Callback<NasaPhoto>() {
            @Override
            public void onResponse(Call<NasaPhoto> call, Response<NasaPhoto> response) {
                if (response.isSuccessful()) {
                    // Aktualizacja widoków
                    NasaPhoto photo = response.body();
                    titleTextView.setText(photo.getTitle());
                    descriptionTextView.setText(photo.getExplanation());
                    Glide.with(MainActivity.this) // Wczytanie zdjęcia z URL
                            .load(photo.getUrl())
                            .into(photoImageView);
                }
            }

            @Override
            public void onFailure(Call<NasaPhoto> call, Throwable t) {
                // Obsługa błędów podczas pobierania danych
                Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Pobieranie zdjęcie z wybranej daty
    private void loadPhotoByDate(String date) {
        NasaApiService apiService = RetrofitClient.getInstance(); // Pobranie instancji Retrofit
        Call<NasaPhoto> call = apiService.getPhotoByDate(API_KEY, date);

        call.enqueue(new Callback<NasaPhoto>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onResponse(Call<NasaPhoto> call, Response<NasaPhoto> response) {
                if (response.isSuccessful()) {
                    // Aktualizacja widoku
                    NasaPhoto photo = response.body();
                    titleTextView.setText(photo.getTitle());
                    descriptionTextView.setText(photo.getExplanation());
                    Glide.with(MainActivity.this) // Wczytanie zdjęcia z URL
                            .load(photo.getUrl())
                            .into(photoImageView);

                    // Obliczanie liczby dni od publikacji
                    calculateDaysSincePublication(photo.getDate());
                } else {
                    Toast.makeText(MainActivity.this, "Error: Could not load photo", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<NasaPhoto> call, Throwable t) {
                // Obsługa błędów podczas pobierania danych
                Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Obliczanie liczby dni od daty publikacji zdjęcia
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void calculateDaysSincePublication(String photoDate) {
        try {
            // Przekształcanie formatu ISO daty na format YYYY-MM-DD
            LocalDate publishedDate = LocalDate.parse(photoDate, DateTimeFormatter.ISO_DATE);
            LocalDate today = LocalDate.now(); // Pobieranie dzisiejszej daty
            long daysBetween = ChronoUnit.DAYS.between(publishedDate, today); // Obliczanie liczby dni od publikacji
            daysSinceTextView.setText("Days since publication: " + daysBetween); // Wyświetlanie wynik
        } catch (Exception e) {
            // Obsługa błędów podczas obliczania
            Toast.makeText(this, "Error calculating days: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
